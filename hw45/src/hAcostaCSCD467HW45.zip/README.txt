Name: Halim Acosta
Description: unzip the submitted hAcostaCSCD467HW45.zip, you get multiple files
To Compile: 
javac *.java
To Run:
=====Tester=============================================================
1.)java Capitalize server
2.)open a second terminal 
3.)java  ServerTester [number of threads] [command type]
	command type can be 
		1.)single - send a single message to the server and quit
		2.)multi - use all the commands of the server and quit
		3.)err - send erroneous commands to the server and quit
	*if run without any parameters the tester be run with 200 threads and command type single
=========================================================================
====Client===============================================================
1.)java CapitalizeServer
2.)java CapitalizeClient
	send kill to quit
=========================================================================